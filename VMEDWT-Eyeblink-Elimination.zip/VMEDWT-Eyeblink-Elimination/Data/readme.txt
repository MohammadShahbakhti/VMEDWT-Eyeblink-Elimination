
The data file contains some examples of contaminated EEG with different SNR categories (raw), artifact-free EEG (eeg), 
eye blink signals (eyeblink), and a white noise (noise). 

Fs=200 Hz, length= 24s. 

For more info about generation of the data, please read "semi-simulated data" section of the paper.

If you have further questions, please feel free to contact me at "mohammad.shahbakhti@ktu.edu" 