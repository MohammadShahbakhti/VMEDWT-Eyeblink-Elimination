function [y] =Filter  (w,fs,k1,n)

out=[];
w=[ zeros(size(w,1),fs/8) w zeros(size(w,1),n*fs/8)];
k1=k1+fs/8;
raw2=[];

Xfilt=zeros(size(w,1),size(w,2));raw2=w;eog=zeros(size(w,1),size(w,2));
X=[];Y=[];
for i=1:size(k1,2)
    xx=[];
    eog(:,k1(i)-(fs/8)+1:(k1(i)+(fs/2-(fs/8))))=w(:,k1(i)-(fs/8)+1:k1(i)+(fs/2-(fs/8)));
end
 Xfilt=ebdwt(eog);
X=raw2-eog;
y=X+Xfilt;
NM=(fs/8)+1;
y=y(:,NM:NM+(n*fs)-1); 
 out=[out y]; 

end


