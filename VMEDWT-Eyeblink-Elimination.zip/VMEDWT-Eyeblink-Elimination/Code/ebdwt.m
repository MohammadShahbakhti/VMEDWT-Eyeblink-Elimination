function [filtEEG]=ebdwt(X) 

e=0;
n=4;
s=[];filtEEG=[];
for i=1:size(X,1)
    x=[];
  x=X(i,:);
[c,l]=wavedec(x,3,'db4');
    c(l(1):l(5))=0;
a1=waverec(c,l,'db4');

s(1,1)=skewness(a1);
clear c l

while e<0.1
       [c,l]=wavedec(x,n,'db4');
    c(l(1):l(n+2))=0;
    a=waverec(c,l,'db4');
    s(n,1)=skewness(a);
    e=abs(abs(s(n,1))-abs(s(n-1,1)));
    n=n+1;
end
m=n-1;
clear c l



[c,l]=wavedec(x,m,'db4');
c(l(1):l(m+2))=0;
extractedeog=waverec(c,l,'db4');
filtEEG=[filtEEG;x-extractedeog];

end
end