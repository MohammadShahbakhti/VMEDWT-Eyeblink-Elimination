function out= VME_DWT(x,fs,n)

%% VME_DWT
% M. Shahbakhti, M. Beiramvand, M. Nazari, A. Broniec-Wojcik, P. Augustyniak, A. Santos Rodrigues, 
% M. Wierzchon, and V. Marozas, VME-DWT: An Efficient Algorithm for Detection and Elimination of 
% Eye Blink from Short Segments of Single EEG Channel, IEEE TRANSACTIONS ON NEURAL SYSTEMS AND 
% REHABILITATION ENGINEERING (TNSRE), Accepted paper, Jan. 2021. DOI: 10.1109/TNSRE.2021.3054733
% Contact: mohammad.shahbakhti@ktu.edu, Initial release 2021-02-13 (c) 2021
% 
%
%Input and parameters:
%
% x - The time domain contaminated EEG signal 
% fs - Sampling frequnecy
% n - Window size (not less than 3s)
%
% Output:
% 
% out - The time domain filtered EEG signal
%
%
%

out=[];
%Windowing
w=windowing(x,fs,n);

for j=1:size(w,1)
   
    %% Detection
  k1=Detect(w(j,:),fs);
  %% Filtering
  y =Filter  (w(j,:),fs,k1,n);
  out=[out y]; 
end


end