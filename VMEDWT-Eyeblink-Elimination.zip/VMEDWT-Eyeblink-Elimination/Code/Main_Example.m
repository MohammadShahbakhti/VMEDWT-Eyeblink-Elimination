close all; clc; clear all

load Sample.mat 


fs=200; %fs is the sampling rate

t=1/fs*(1:length(x)); % Time vector in seconds 

n=3; %N in the window size 

y = VME_DWT(x,fs,n);

%y is the filtered signal
%x is the input signal (contaminated)

plot(t,x),hold on, plot(t,y), xlabel('Time(s)'), legend('Noisy EEG','Filtered EEG')

clear fs n t 
