
This file contains the codes for VME-DWT algorithm to remove eye blinks from a short segment of the single EEG channel.

For ease of use, Please run the Main Example.m file. 
Input parameters: x (contaminated EEG), N (window size), and Fs (sampling frequnecy). 
Output: y (filtered EEG)

In case of any problems or requiring adjustment of the parameters, feel free to contact me at mohammad.shahbakhti@ktu.edu


 