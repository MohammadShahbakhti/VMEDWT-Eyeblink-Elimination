function w = windowing(x,fs,n)

r=fs*n;

for i=1:length(x)/r
    w(i,:)=x((i-1)*r+1:r*i);
end
end
