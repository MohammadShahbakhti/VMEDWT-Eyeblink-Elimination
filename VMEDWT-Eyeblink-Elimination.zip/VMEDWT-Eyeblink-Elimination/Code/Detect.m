function [k1 ] =Detect  (w,fs)
g=[];
w=[zeros(1,fs/8) w zeros(1,3*fs/8)];
[eeb,~,~]=vme(w,3000,0.003,0,1e-6);
k=[];g=zeros(1,size(w,2));nk=[];
for i=2:length(w)-1
    if eeb(i)>eeb(i+1) && eeb(i)>eeb(i-1)
        k=[k i];
    end
    
end

r=eeb(k);

k1=[];g=zeros(1,size(w,2));
m=median(abs(eeb))./0.6745.*sqrt(2*log(length(eeb)));
%m=1.5*std(eeb);
for i=1:length(r)
    if r(i)>m 
        k1=[k1 k(i)];
    else
     
    end
    
end
k1=k1-fs/8;

g(k1)=w(k1);
G=g(k1);
end
